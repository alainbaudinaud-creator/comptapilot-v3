--
-- PostgreSQL database dump
--

\restrict g31oQujMP0utTNO950iYCDyGRAoycxVUWZkixSo98O1WTqsQwhYFvS5G9vOzFSi

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: societes_clientes_premium; Type: TABLE; Schema: public; Owner: comptapilot
--

CREATE TABLE public.societes_clientes_premium (
    id integer NOT NULL,
    nom text NOT NULL,
    siren text,
    siret text,
    tva_intracom text,
    adresse text,
    code_postal text,
    ville text,
    forme_juridique text,
    activite_ape text,
    etat_administratif text,
    email text,
    statut text DEFAULT 'ACTIF'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.societes_clientes_premium OWNER TO comptapilot;

--
-- Name: societes_clientes_premium_id_seq; Type: SEQUENCE; Schema: public; Owner: comptapilot
--

CREATE SEQUENCE public.societes_clientes_premium_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.societes_clientes_premium_id_seq OWNER TO comptapilot;

--
-- Name: societes_clientes_premium_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comptapilot
--

ALTER SEQUENCE public.societes_clientes_premium_id_seq OWNED BY public.societes_clientes_premium.id;


--
-- Name: societes_clientes_premium id; Type: DEFAULT; Schema: public; Owner: comptapilot
--

ALTER TABLE ONLY public.societes_clientes_premium ALTER COLUMN id SET DEFAULT nextval('public.societes_clientes_premium_id_seq'::regclass);


--
-- Data for Name: societes_clientes_premium; Type: TABLE DATA; Schema: public; Owner: comptapilot
--

COPY public.societes_clientes_premium (id, nom, siren, siret, tva_intracom, adresse, code_postal, ville, forme_juridique, activite_ape, etat_administratif, email, statut, created_at) FROM stdin;
1	BM IMMOBILIER	879789618	87978961800011	FR30879789618	ZA LES FOUGEROUSES ROUTE DE BEAUREGARD 16430 BALZAC	16430	BALZAC	5499	68.20B	A		ACTIF	2026-05-28 00:13:40.570716
\.


--
-- Name: societes_clientes_premium_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comptapilot
--

SELECT pg_catalog.setval('public.societes_clientes_premium_id_seq', 1, true);


--
-- Name: societes_clientes_premium societes_clientes_premium_pkey; Type: CONSTRAINT; Schema: public; Owner: comptapilot
--

ALTER TABLE ONLY public.societes_clientes_premium
    ADD CONSTRAINT societes_clientes_premium_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict g31oQujMP0utTNO950iYCDyGRAoycxVUWZkixSo98O1WTqsQwhYFvS5G9vOzFSi

