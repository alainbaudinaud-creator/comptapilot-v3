﻿# Package OpenAI réel
