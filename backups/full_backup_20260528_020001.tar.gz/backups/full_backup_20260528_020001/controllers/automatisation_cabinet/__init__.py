﻿# Package automatisation cabinet
