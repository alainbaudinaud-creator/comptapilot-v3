--
-- PostgreSQL database dump
--

\restrict 2K0mnQlCUSsvOwaKcHZrc0GqxbbhCEdOCUasXXdTeT7Wxe85sMfWla75EZdJj9A

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ecritures_premium; Type: TABLE; Schema: public; Owner: comptapilot
--

CREATE TABLE public.ecritures_premium (
    id integer NOT NULL,
    societe_id integer,
    journal text,
    date_ecriture text,
    compte_debit text,
    compte_credit text,
    libelle text,
    montant_ttc numeric(14,2) DEFAULT 0,
    statut text DEFAULT 'BROUILLON'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ecritures_premium OWNER TO comptapilot;

--
-- Name: ecritures_premium_id_seq; Type: SEQUENCE; Schema: public; Owner: comptapilot
--

CREATE SEQUENCE public.ecritures_premium_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecritures_premium_id_seq OWNER TO comptapilot;

--
-- Name: ecritures_premium_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comptapilot
--

ALTER SEQUENCE public.ecritures_premium_id_seq OWNED BY public.ecritures_premium.id;


--
-- Name: ecritures_premium id; Type: DEFAULT; Schema: public; Owner: comptapilot
--

ALTER TABLE ONLY public.ecritures_premium ALTER COLUMN id SET DEFAULT nextval('public.ecritures_premium_id_seq'::regclass);


--
-- Data for Name: ecritures_premium; Type: TABLE DATA; Schema: public; Owner: comptapilot
--

COPY public.ecritures_premium (id, societe_id, journal, date_ecriture, compte_debit, compte_credit, libelle, montant_ttc, statut, created_at) FROM stdin;
\.


--
-- Name: ecritures_premium_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comptapilot
--

SELECT pg_catalog.setval('public.ecritures_premium_id_seq', 1, false);


--
-- Name: ecritures_premium ecritures_premium_pkey; Type: CONSTRAINT; Schema: public; Owner: comptapilot
--

ALTER TABLE ONLY public.ecritures_premium
    ADD CONSTRAINT ecritures_premium_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 2K0mnQlCUSsvOwaKcHZrc0GqxbbhCEdOCUasXXdTeT7Wxe85sMfWla75EZdJj9A

